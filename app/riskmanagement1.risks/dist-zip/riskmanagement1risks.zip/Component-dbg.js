sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("riskmanagement1.risks.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);