sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("riskmanagement1.risks.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map